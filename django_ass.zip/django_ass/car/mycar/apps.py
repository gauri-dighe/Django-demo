from django.apps import AppConfig


class MycarConfig(AppConfig):
    name = 'mycar'
